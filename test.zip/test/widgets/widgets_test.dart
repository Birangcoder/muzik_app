import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:muzik/app/routes.dart';
import 'package:muzik/core/error/api_exception.dart';
import 'package:muzik/core/widgets/app_error_view.dart';
import 'package:muzik/features/home/data/models/home_model.dart';
import 'package:muzik/features/home/presentation/pages/home_screen.dart';
import 'package:muzik/features/song/data/models/song_model.dart';
import 'package:muzik/features/song/presentation/pages/song_page.dart';
import 'package:muzik/features/song/presentation/widgets/like_and_play_row.dart';
import 'package:muzik/features/song/presentation/widgets/now_playing_body.dart';
import 'package:muzik/features/song/presentation/widgets/paginated_song_list_view.dart';
import 'package:muzik/features/song/presentation/widgets/stats_row.dart';
import 'package:muzik/shared/widgets/song_list_tile.dart';

import '../helpers/fakes.dart';
import '../helpers/test_data.dart';

/// Text that must NEVER be visible to a user.
final _rawErrors = [
  find.textContaining('is not a subtype'),
  find.textContaining('Null check'),
  find.textContaining('Exception'),
  find.textContaining('type \'Null\''),
  find.textContaining('NoSuchMethod'),
  find.textContaining('RangeError'),
  find.textContaining('FormatException'),
];

void expectNoRawErrors(WidgetTester tester) {
  expect(tester.takeException(), isNull);
  for (final f in _rawErrors) {
    expect(f, findsNothing);
  }
}

Future<void> pumpUntilFound(
  WidgetTester tester,
  Finder finder, {
  int maxPumps = 10,
}) async {
  for (var i = 0; i < maxPumps; i++) {
    if (finder.evaluate().isNotEmpty) return;

    await tester.pump(const Duration(milliseconds: 50));
  }
}

Future<void> pumpUntilGone(
  WidgetTester tester,
  Finder finder, {
  int maxPumps = 10,
}) async {
  for (var i = 0; i < maxPumps; i++) {
    if (finder.evaluate().isEmpty) return;

    await tester.pump(const Duration(milliseconds: 50));
  }
}

void main() {
  setUpAll(configureTestEnvironment);

  group('SongListTile', () {
    testWidgets('song with no artists and no cover renders', (tester) async {
      await tester.pumpWidget(
        wrap(Scaffold(body: SongListTile(song: nullSong()))),
      );
      await tester.pump();
      expect(find.text('Untitled'), findsOneWidget);
      expectNoRawErrors(tester);
    });

    testWidgets('shows artist names', (tester) async {
      await tester.pumpWidget(
        wrap(Scaffold(body: SongListTile(song: fullSong()))),
      );
      await tester.pump();
      expect(find.text('Song 1'), findsOneWidget);
      expect(find.text('Artist A'), findsOneWidget);
    });
  });

  group('StatsRow', () {
    testWidgets('missing release date and plays -> no crash', (tester) async {
      await tester.pumpWidget(
        wrap(
          const Scaffold(body: StatsRow(playCount: null, releaseDate: null)),
        ),
      );
      expectNoRawErrors(tester);
      expect(find.byIcon(Icons.calendar_today_rounded), findsNothing);
    });

    testWidgets('shows date and plays when present', (tester) async {
      await tester.pumpWidget(
        wrap(
          Scaffold(
            body: StatsRow(playCount: 1200, releaseDate: DateTime(2024, 5, 1)),
          ),
        ),
      );
      expect(find.text('1,200 plays'), findsOneWidget);
      expect(find.text('1 May 2024'), findsOneWidget);
    });
  });

  group('NowPlayingBody', () {
    for (final entry in {
      'every field null': nullSong,
      'complete song': fullSong,
    }.entries) {
      testWidgets(entry.key, (tester) async {
        useLargeScreen(tester);
        await tester.pumpWidget(
          wrap(
            Scaffold(body: NowPlayingBody(song: entry.value())),
            overrides: baseOverrides(),
          ),
        );
        await tester.pump();
        await tester.pump();
        expectNoRawErrors(tester);
      });
    }
  });

  group('LikeAndPlayRow', () {
    testWidgets('failed like shows a friendly message', (tester) async {
      useLargeScreen(tester);
      final repo = FakeSongRepository(
        addFavoriteError: const ApiException(
          'Please log in first',
          statusCode: 401,
        ),
      );
      await tester.pumpWidget(
        wrap(
          const Scaffold(body: LikeAndPlayRow(likeCount: null, songId: 1)),
          overrides: baseOverrides(songs: repo),
        ),
      );
      await tester.pump();
      await tester.pump();

      await tester.tap(find.byIcon(Icons.favorite_border_rounded));
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 300));

      expect(find.text('Please log in first'), findsOneWidget);
      expectNoRawErrors(tester);
    });

    testWidgets('unexpected error type is hidden behind a generic message', (
      tester,
    ) async {
      useLargeScreen(tester);
      final repo = FakeSongRepository(
        addFavoriteError: StateError('db exploded'),
      );
      await tester.pumpWidget(
        wrap(
          const Scaffold(body: LikeAndPlayRow(likeCount: null, songId: 1)),
          overrides: baseOverrides(songs: repo),
        ),
      );
      await tester.pump();
      await tester.pump();
      await tester.tap(find.byIcon(Icons.favorite_border_rounded));
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 300));

      expect(find.textContaining('db exploded'), findsNothing);
      expect(
        find.text('Something went wrong. Please try again.'),
        findsOneWidget,
      );
    });
  });

  group('SongPage', () {
    testWidgets('null-heavy song loads, plays once, shows no raw errors', (
      tester,
    ) async {
      useLargeScreen(tester);
      final player = FakeAudioPlayer();
      final repo = FakeSongRepository(song: playableNullSong(id: 7));
      await tester.pumpWidget(
        wrap(
          const SongPage(songId: 7),
          overrides: baseOverrides(player: player, songs: repo),
        ),
      );
      await tester.pump();
      await tester.pump();
      await tester.pump();
      await tester.pump(const Duration(milliseconds: 50));

      expect(find.text('Untitled'), findsOneWidget);
      expect(player.loadedUrls, hasLength(1));
      expectNoRawErrors(tester);
    });

    testWidgets('load error shows a friendly message and Retry works', (
      tester,
    ) async {
      useLargeScreen(tester);

      final repo = FakeSongRepository(
        songError: const ApiException('No internet connection.', statusCode: 0),
      );

      await tester.pumpWidget(
        wrap(const SongPage(songId: 1), overrides: baseOverrides(songs: repo)),
      );

      // Wait for the FutureProvider error state.
      await pumpUntilFound(tester, find.text("Couldn't load this song"));

      expect(repo.fetchSongCalls, 1);

      expect(find.text("Couldn't load this song"), findsOneWidget);

      expect(find.text('No internet connection.'), findsOneWidget);

      expect(find.text('Retry'), findsOneWidget);

      expectNoRawErrors(tester);

      // Simulate the internet connection recovering.
      repo.songError = null;
      repo.song = fullSong();

      await tester.tap(find.text('Retry'));

      await pumpUntilFound(tester, find.text('Song 1'));

      expect(repo.fetchSongCalls, 2);
      expect(find.text('Song 1'), findsOneWidget);

      expectNoRawErrors(tester);
    });

    testWidgets('unexpected exception type is not shown raw', (tester) async {
      useLargeScreen(tester);
      final repo = FakeSongRepository(songError: makeTypeError());
      await tester.pumpWidget(
        wrap(const SongPage(songId: 1), overrides: baseOverrides(songs: repo)),
      );
      await tester.pump();
      await tester.pump();
      expect(
        find.text('Something went wrong. Please try again.'),
        findsOneWidget,
      );
      expectNoRawErrors(tester);
    });
  });

  group('HomeScreen', () {
    testWidgets('all sections null -> renders without errors', (tester) async {
      useLargeScreen(tester);
      final home = FakeHomeRepository(
        home: HomeModel.fromJson({
          'trending': null,
          'popular': null,
          'recommended': null,
          'new_release': null,
          'continue_listening': null,
          'top_artists': null,
          'top_albums': null,
        }),
      );
      await tester.pumpWidget(
        wrap(
          const Scaffold(body: HomeScreen()),
          overrides: baseOverrides(home: home),
        ),
      );
      await tester.pump();
      await tester.pump();
      expect(find.text('trending'), findsOneWidget);
      expectNoRawErrors(tester);
    });

    testWidgets('songs with missing artists / covers render', (tester) async {
      useLargeScreen(tester);
      final home = FakeHomeRepository(
        home: HomeModel.fromJson({
          'trending': [nullSongJson(id: 1), fullSongJson(id: 2)],
          'new_release': [nullSongJson(id: 3)],
          'popular': [nullSongJson(id: 4)],
          'recommended': [nullSongJson(id: 5)],
          'continue_listening': [nullSongJson(id: 6)],
          'top_artists': [
            {'id': 1, 'name': null, 'image_url': null},
          ],
          'top_albums': [
            {'id': 1, 'title': null, 'cover_url': null},
          ],
        }),
      );
      await tester.pumpWidget(
        wrap(
          const Scaffold(body: HomeScreen()),
          overrides: baseOverrides(home: home),
        ),
      );
      await tester.pump();
      await tester.pump();
      expectNoRawErrors(tester);
    });

    testWidgets('network failure -> friendly error + working Retry', (
      tester,
    ) async {
      useLargeScreen(tester);

      final home = FakeHomeRepository(
        error: const ApiException('No internet connection.', statusCode: 0),
      );

      await tester.pumpWidget(
        wrap(
          const Scaffold(body: HomeScreen()),
          overrides: baseOverrides(home: home),
        ),
      );

      // Wait for the FutureProvider error state.
      await pumpUntilFound(tester, find.text("Couldn't load your music"));

      expect(home.calls, 1);

      expect(find.text("Couldn't load your music"), findsOneWidget);

      expect(find.text('No internet connection.'), findsOneWidget);

      expect(find.text('Retry'), findsOneWidget);

      expectNoRawErrors(tester);

      // Simulate network recovery.
      home.error = null;

      await tester.tap(find.text('Retry'));

      await pumpUntilGone(tester, find.text("Couldn't load your music"));

      expect(home.calls, 2);

      expect(find.text("Couldn't load your music"), findsNothing);

      expectNoRawErrors(tester);
    });

    testWidgets('type error from the repository is not shown raw', (
      tester,
    ) async {
      useLargeScreen(tester);
      final home = FakeHomeRepository(error: makeTypeError());
      await tester.pumpWidget(
        wrap(
          const Scaffold(body: HomeScreen()),
          overrides: baseOverrides(home: home),
        ),
      );
      await tester.pump();
      await tester.pump();
      expect(
        find.text('Something went wrong. Please try again.'),
        findsOneWidget,
      );
      expectNoRawErrors(tester);
    });
  });

  group('PaginatedSongListView', () {
    Widget list({Object? error, List<SongModel> tracks = const []}) => wrap(
      PaginatedSongListView(
        title: 'Trending',
        tracks: tracks,
        isLoading: false,
        isLoadingMore: false,
        hasNext: false,
        error: error,
        onRefresh: () async {},
        onLoadMore: () {},
      ),
    );

    testWidgets('error state shows friendly text', (tester) async {
      await tester.pumpWidget(list(error: makeTypeError()));
      expect(find.text("Couldn't load Trending songs"), findsOneWidget);
      expect(
        find.text('Something went wrong. Please try again.'),
        findsOneWidget,
      );
      expectNoRawErrors(tester);
    });

    testWidgets('api error message is shown', (tester) async {
      await tester.pumpWidget(
        list(error: const ApiException('Server is down', statusCode: 503)),
      );
      expect(find.text('Server is down'), findsOneWidget);
    });

    testWidgets('empty state', (tester) async {
      await tester.pumpWidget(list());
      expect(find.text('No Trending songs right now'), findsOneWidget);
    });

    testWidgets('tracks with null fields render', (tester) async {
      await tester.pumpWidget(list(tracks: [nullSong(id: 1), fullSong(id: 2)]));
      await tester.pump();
      expect(find.text('Untitled'), findsOneWidget);
      expect(find.text('Song 2'), findsOneWidget);
      expectNoRawErrors(tester);
    });
  });

  group('Error widgets', () {
    testWidgets('AppErrorView never prints raw exceptions', (tester) async {
      await tester.pumpWidget(
        wrap(Scaffold(body: AppErrorView(error: makeTypeError()))),
      );
      expect(
        find.text('Something went wrong. Please try again.'),
        findsOneWidget,
      );
      expectNoRawErrors(tester);
    });

    testWidgets('AppErrorView retry callback fires', (tester) async {
      var retried = 0;
      await tester.pumpWidget(
        wrap(
          Scaffold(
            body: AppErrorView(message: 'x', onRetry: () => retried++),
          ),
        ),
      );
      await tester.tap(find.text('Retry'));
      expect(retried, 1);
    });

    testWidgets('RouteErrorPage shows a friendly message', (tester) async {
      await tester.pumpWidget(wrap(const RouteErrorPage()));
      expect(find.text('Page not found'), findsOneWidget);
    });

    testWidgets('a widget that throws while building shows the safe fallback', (
      tester,
    ) async {
      final original = ErrorWidget.builder;

      try {
        ErrorWidget.builder = (details) => const AppErrorWidget();

        await tester.pumpWidget(
          wrap(
            Scaffold(body: Builder(builder: (_) => throw StateError('boom'))),
          ),
        );

        expect(tester.takeException(), isNotNull);

        expect(find.text('Something went wrong.'), findsOneWidget);

        expect(find.textContaining('boom'), findsNothing);
      } finally {
        ErrorWidget.builder = original;
      }
    });
  });
}
